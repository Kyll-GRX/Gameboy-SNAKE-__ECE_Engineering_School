#include <Arduino.h>
float tension;

void setup() {
  Serial.begin(9600);
}

void loop() {
  tension = analogRead(4)*3.0 /1023.0;
  Serial.println(tension);
  delay(500);
}

